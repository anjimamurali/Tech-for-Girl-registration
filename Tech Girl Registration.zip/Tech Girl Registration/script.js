// let clickCount = Number(localStorage.getItem("clickCount")) || 0;
// const maxClicks = 5;

// const form = document.getElementById("registrationForm");
// const shareBtn = document.getElementById("shareBtn");
// const submitBtn = document.getElementById("submitBtn");
// const clickDisplay = document.getElementById("clickCount");
// const successMessage = document.getElementById("successMessage");

// document.addEventListener("DOMContentLoaded", () => {
//   const submitted = localStorage.getItem("submitted");
//   clickCount = Number(localStorage.getItem("clickCount")) || 0;
//   clickDisplay.textContent = 'Click count: ${clickCount}/5';

//   if (submitted) {
//     disableForm();
//     successMessage.classList.remove("hidden");
//   }
// });

// shareBtn.addEventListener("click", () => {
//   if (clickCount >= maxClicks) return;

//   const text = encodeURIComponent("Hey Buddy, Join Tech For Girls Community!");
//   const url = 'https://wa.me/?text=${text}';
//   window.open(url, "_blank");

//   clickCount++;
//   localStorage.setItem("clickCount", clickCount);
//   clickDisplay.textContent = 'Click count: ${clickCount}/5';

//   if (clickCount === maxClicks) {
//     alert("✅ Sharing complete. You can now submit the form.");
//   }
// });

// form.addEventListener("submit", async (e) => {
//   e.preventDefault();

//   if (clickCount < maxClicks) {
//     alert("⚠️ Please share 5 times on WhatsApp before submitting.");
//     return;
//   }

//   const formData = new FormData(form);
//   const name = formData.get("name");
//   const phone = formData.get("phone");
//   const email = formData.get("email");
//   const college = formData.get("college");
//   const file = formData.get("screenshot");

//   if (!file) {
//     alert("⚠️ Please upload your screenshot.");
//     return;
//   }

//   const payload = new FormData();
//   payload.append("name", name);
//   payload.append("phone", phone);
//   payload.append("email", email);
//   payload.append("college", college);
//   payload.append("screenshot", file);

//   console.log("Submitting data:", name, phone, email, college, file.name);

//   try {
//     await fetch(
//       "https://script.google.com/macros/s/AKfycbwbT9MK_bNxOjvoe9a43STZWRLZGOKcuUT1wTchpYyrsdgLR2mYih4G-EUr7dfPEryp_Q/exec",
//       {
//         method: "POST",
//         body: payload,
//         mode: "no-cors",
//       }
//     );

//     localStorage.setItem("submitted", true);
//     disableForm();
//     successMessage.classList.remove("hidden");

//     setTimeout(() => {
//     localStorage.clear();
//     sessionStorage.clear();
    
//     console.log("✅ Local storage cleared after submission.");
//   }, 5000); 
//   } catch (err) {
//     alert("❌ Something went wrong. Please try again later.");
//     console.error(err);

//   localStorage.clear();
//   sessionStorage.clear();
//   console.log("🧹 Cleared local and session storage due to error.");
//   }
// });
// document.getElementById("someButton").addEventListener("click", function()  {
//   window.location.reload();
// });

// function disableForm() {
//   form.querySelectorAll("input, button").forEach((el) => (el.disabled = true));
// }

// // Optional reset function for testing
// function resetForm() {
//   localStorage.removeItem("submitted");
//   localStorage.removeItem("clickCount");
//   window.location.reload();
// }

let clickCount = Number(localStorage.getItem("clickCount")) || 0;
const maxClicks = 5;

const form = document.getElementById("registrationForm");
const shareBtn = document.getElementById("shareBtn");
const submitBtn = document.getElementById("submitBtn");
const clickDisplay = document.getElementById("clickCount");
const successMessage = document.getElementById("successMessage");

document.addEventListener("DOMContentLoaded", () => {
  const submitted = localStorage.getItem("submitted");
  clickCount = Number(localStorage.getItem("clickCount")) || 0;
  clickDisplay.textContent = `Click count: ${clickCount}/5`;

  if (submitted) {
    disableForm();
    successMessage.classList.remove("hidden");
  }

  // ✅ Fix: only attach if the button exists
  const someButton = document.getElementById("someButton");
  if (someButton) {
    someButton.addEventListener("click", function () {
      window.location.reload();
    });
  }

  // ✅ Disable share button if max reached
  if (clickCount >= maxClicks) {
    shareBtn.disabled = true;
  }
});

shareBtn.addEventListener("click", () => {
  if (clickCount >= maxClicks) return;

  const text = encodeURIComponent("Hey Buddy, Join Tech For Girls Community!");
  const url = `https://wa.me/?text=${text}`;
  window.open(url, "_blank");

  clickCount++;
  localStorage.setItem("clickCount", clickCount);
  clickDisplay.textContent = `Click count: ${clickCount}/5`;

  if (clickCount >= maxClicks) {
    alert("✅ Sharing complete. You can now submit the form.");
    shareBtn.disabled = true;
  }
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  if (clickCount < maxClicks) {
    alert("⚠️ Please share 5 times on WhatsApp before submitting.");
    return;
  }

  const formData = new FormData(form);
  const name = formData.get("name");
  const phone = formData.get("phone");
  const email = formData.get("email");
  const college = formData.get("college");
  const file = formData.get("screenshot");

  if (!file) {
    alert("⚠️ Please upload your screenshot.");
    return;
  }

  const payload = new FormData();
  payload.append("name", name);
  payload.append("phone", phone);
  payload.append("email", email);
  payload.append("college", college);
  payload.append("screenshot", file);

  console.log("Submitting data:", name, phone, email, college, file.name);

  try {
    await fetch(
      "https://script.google.com/macros/s/AKfycbwbT9MK_bNxOjvoe9a43STZWRLZGOKcuUT1wTchpYyrsdgLR2mYih4G-EUr7dfPEryp_Q/exec",
      {
        method: "POST",
        body: payload,
        mode: "no-cors",
      }
    );

    localStorage.setItem("submitted", true);
    disableForm();
    successMessage.classList.remove("hidden");

    setTimeout(() => {
      localStorage.clear();
      sessionStorage.clear();
      console.log("✅ Local and session storage cleared after submission.");
    }, 5000);
  } catch (err) {
    alert("❌ Something went wrong. Please try again later.");
    console.error(err);

    localStorage.clear();
    sessionStorage.clear();
    console.log("🧹 Cleared local and session storage due to error.");
  }
});

function disableForm() {
  form.querySelectorAll("input, button").forEach((el) => (el.disabled = true));
}

// Optional reset function for testing
function resetForm() {
  localStorage.removeItem("submitted");
  localStorage.removeItem("clickCount");
  window.location.reload();
}
