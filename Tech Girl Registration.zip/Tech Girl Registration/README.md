# 🚀 Tech for Girls Registration Form

A web-based registration form built using **HTML**, **CSS**, and **JavaScript** to promote the **Tech for Girls** initiative. This form includes WhatsApp sharing validation, screenshot upload, and Google Apps Script integration for backend data collection.




 Features

-  User registration with:
  - Name
  - Phone Number
  - Email
  - College/Department
  - Screenshot upload
-  WhatsApp sharing (5 times required before submission)
-  Form submission via Google Apps Script
-  Progress saved using `localStorage`
-  Auto-disables form after successful submission

RUN- Open with Live Server

